﻿using DataProcessing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UIMenu
{
    public abstract  class MenuPage 
    {
        internal delegate void PageActionEventHandler(object sender);

        internal event PageActionEventHandler? ActionActivated;

        public readonly string? _title;
        private int _indexOfSelectedActions;
        public virtual  List<MenuPageAction>? MenuPageActions { get; }

        public virtual string? Title { get { return _title; } }
        public virtual int IndexAction 
        {
            get { return _indexOfSelectedActions; }
            set { _indexOfSelectedActions = value; } 
        }
        public void StartAction()
        {
            ActionActivated?.Invoke(this);
        }
        
        public static void Clear()
        {
            Console.Clear();
            Console.Write("\x1b[3J");
        }
        public virtual void SwitchingMenuItems()
        {
            bool select = false;
            ConsoleKeyInfo key;

            while (!select)
            {
                Clear();
                Console.CursorVisible = false;
                ShowMenu();
                key = Console.ReadKey(true);
                ProcessKeyPress(this, key, ref select);
            }
        }

        internal virtual void ShowMenu()
        {
            ShowMenuPage(MenuPageActions);
        }
        protected void ShowMenuPage(List<MenuPageAction> menuPageActions)
        {
            for (int i = 0; i < menuPageActions.Count; i++)
            {
                if (i == IndexAction)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(menuPageActions[i].Name);
                    Console.ResetColor();
                }
                else
                    Console.WriteLine(menuPageActions[i].Name);
            }
        }
        protected virtual void ProcessKeyPress(MenuPage change, ConsoleKeyInfo key, ref bool select)
        {
            switch (key.Key)
            {
                case ConsoleKey.DownArrow or ConsoleKey.S:
                    change.IndexAction = IncrementIndex(change.IndexAction, change.MenuPageActions.Count ) ;
                    break;
                case ConsoleKey.UpArrow or ConsoleKey.W:
                    change.IndexAction = DecrementIndex(change.IndexAction, change.MenuPageActions.Count );
                    break;
                case ConsoleKey.Enter:
                    PerformIndividualActions();
                    select = true;
                    break;
                case ConsoleKey.Backspace:
                    MenuStack.StackMenuPage.Pop();
                    select = true;
                    break;
                case ConsoleKey.Escape:
                    DataStorage.StatusProgram = false;
                    select = true;
                    break;
                default:
                    break;
            }
        }
        protected virtual void PerformIndividualActions()
        {
            ActionActivated += MenuPageActions[IndexAction].PageActionEnventHandler;
            Clear();
            StartAction();
            ActionActivated -= MenuPageActions[IndexAction].PageActionEnventHandler;
        }

        internal int IncrementIndex(int currentIndex, int maxIndex)
            => currentIndex == maxIndex - 1 ? 0 : currentIndex + 1;
        

        internal int DecrementIndex(int currentIndex, int maxIndex)
            => currentIndex == 0 ? maxIndex - 1 : currentIndex - 1;

        public static void Exit()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.WriteLine("Shutdown of the program...");            
            Console.ForegroundColor = ConsoleColor.Red;

            string[] frames = { "⠁", "⠈", "⠐", "⠠", "⢀", "⡀", "⠄", "⠂" };
            int counter = 0;
            for (int i = 0; i < 20; i++)
            {                
                Console.Write("\r{0} ", frames[counter % 8]);
                counter++;
                Thread.Sleep(100); 
            }
            Console.ResetColor();
            Clear();
        }
    }

}
