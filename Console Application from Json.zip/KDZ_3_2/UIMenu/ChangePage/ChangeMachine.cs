﻿using DataProcessing;

namespace UIMenu.ChangePage
{
    /// <summary>
    /// Represents a menu page for changing machine properties.
    /// </summary>
    internal class ChangeMachine : ChangeObjectPage
    {
        
        private new int _indexOfSelectedActions;

        /// <summary>
        /// Gets or sets the index of the selected action.
        /// </summary>
        public override int IndexAction
        {
            get { return _indexOfSelectedActions; }
            set { _indexOfSelectedActions = value; }
        }

        /// <summary>
        /// Gets the list of menu page actions.
        /// </summary>
        public override List<MenuPageAction>? MenuPageActions { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ChangeMachine"/> class.
        /// </summary>
        public ChangeMachine()
        {
            MenuPageActions = CreateActionsToChangeMachine(DataStorage.IndexObjectToChange);
        }

        /// <summary>
        /// Creates a list of menu page actions for changing properties of a machine object.
        /// </summary>
        /// <param name="indexMachine">The index of the machine to be changed.</param>
        /// <returns>The list of menu page actions.</returns>
        private static List<MenuPageAction> CreateActionsToChangeMachine(int indexMachine)
        {
            // Define the selected fields for machine properties to be changed.
            Machine.FieldsToChange[] selectedField = { Machine.FieldsToChange.Brand, Machine.FieldsToChange.Model, Machine.FieldsToChange.Price, Machine.FieldsToChange.Year, Machine.FieldsToChange.Repairs };
            List<MenuPageAction> pageActions = new();

            // Retrieve the machine object to be changed.
            Machine machineToChange = DataStorage.ModifiedMachines[indexMachine];

            // Create menu page actions for each selected field.
            foreach (var field in selectedField)
            {
                // Define the action for changing the field and launching update.
                Action changeAction = () => { machineToChange.ChangeMachine(field); LaunchUpdate(machineToChange); };

                // Create a menu page action with the field name and associated action.
                MenuPageAction action = new($"{field}", changeAction);

                // Add the action to the list of page actions.
                pageActions.Add(action);
            }
            return pageActions;
        }
        /// <summary>
        /// Handles the navigation through menu items.
        /// </summary>
        public override void SwitchingMenuItems()
        {
            bool select = false;
            ConsoleKeyInfo key;

            // Loop until a menu item is selected.
            while (!select)
            {
                Clear();
                Console.CursorVisible = false;
                ShowMenu();
                key = Console.ReadKey(true);

                // Process the key press event.
                ProcessKeyPress(this, key, ref select);
            }
        }

        /// <summary>
        /// Processes the key press event.
        /// </summary>
        /// <param name="change">The current menu page being navigated.</param>
        /// <param name="key">The pressed key.</param>
        /// <param name="select">A flag indicating whether an action has been selected.</param>
        protected override void ProcessKeyPress(MenuPage change, ConsoleKeyInfo key, ref bool select)
        {
            switch (key.Key)
            {
                case ConsoleKey.DownArrow or ConsoleKey.S:
                    change.IndexAction = IncrementIndex(change.IndexAction, change.MenuPageActions.Count);
                    break;
                case ConsoleKey.UpArrow or ConsoleKey.W:
                    change.IndexAction = DecrementIndex(change.IndexAction, change.MenuPageActions.Count);
                    break;

                // Perform the selected action.
                case ConsoleKey.Enter:
                    PerformIndividualActions();

                    // Display success message if the action was not to change a repair.
                    if (IndexAction != 4)
                    {
                        Clear();
                        Console.WriteLine("The changing was successful!");
                        Thread.Sleep(1000);
                    }                    
                    select = true;
                    break;

                // Navigate back.
                case ConsoleKey.Backspace:
                    MenuStack.StackMenuPage.Pop();
                    MenuStack.StackMenuPage.Pop();
                    select = true;
                    break;
                // Exit the program.
                case ConsoleKey.Escape:
                    DataStorage.StatusProgram = false;
                    select = true;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Shows the menu.
        /// </summary>
        internal override void ShowMenu()
        {
            Console.WriteLine("To end the program, click Escape. To go back, click Backspace.");
            ShowMenuPage(MenuPageActions);
        }

        /// <summary>
        /// Performs individual actions based on the selected menu item.
        /// </summary>
        protected override void PerformIndividualActions()
        {
            if (IndexAction == 4)
            {
                MenuStack.StackMenuPage.Push(new ChangeRepair(DataStorage.IndexObjectToChange));                
            }
            else
            {
                ActionActivated += MenuPageActions[IndexAction].PageActionEnventHandler;
                Clear();
                StartAction();
                ActionActivated -= MenuPageActions[IndexAction].PageActionEnventHandler;
            }
        }
    }
}
