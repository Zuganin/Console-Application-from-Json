﻿using DataProcessing;

namespace UIMenu.ChangePage
{
    /// <summary>
    /// Represents a page for changing repair properties.
    /// </summary>
    internal class ChangeRepair : ChangeObjectPage
    {
        // Index of the selected action.
        private int _indexOfSelectedActions;

        public override int IndexAction
        {
            get { return _indexOfSelectedActions; }
            set { _indexOfSelectedActions = value; }
        }

        public override List<MenuPageAction>? MenuPageActions { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ChangeRepair"/> class with the specified index of the repair object to change.
        /// </summary>
        /// <param name="indexObjectToChange">The index of the repair object to change.</param>
        public ChangeRepair(int indexObjectToChange)
        {
            // Create actions to change repair properties based on the specified repair object index.
            MenuPageActions = CreateActionsToChangeRepairs(indexObjectToChange);
        }

        /// <summary>
        /// Creates actions to change repair properties.
        /// </summary>
        /// <param name="indexMachine">The index of the machine containing the repair object.</param>
        /// <returns>A list of menu page actions for changing repair properties.</returns>
        private static List<MenuPageAction> CreateActionsToChangeRepairs(int indexMachine)
        {
            List<MenuPageAction> pageActions = new();
            Machine machineToChange = DataStorage.ModifiedMachines[indexMachine];

            // Iterate through each repair object in the machine and create actions for changing its properties.
            for (int i = 0; i < machineToChange.Repairs.Count; i++)
            {
                Repair? repairToChange = machineToChange.Repairs[i];

                // Create action for creating a random repair.
                Action randomAction = () =>
                {
                    machineToChange.CreateRandomRepair();
                    repairToChange.CheckStatus();
                    LaunchUpdate(repairToChange);
                };
                MenuPageAction random = new MenuPageAction($"Create random repair", randomAction);
                pageActions.Add(random);

                // Create actions for each property of the repair object.
                foreach (var field in Enum.GetValues(typeof(Repair.FieldsToChange)))
                {
                    Action changeAction = () =>
                    {
                        repairToChange.ChangeRepair((Repair.FieldsToChange)field);
                        repairToChange.CheckStatus();
                        LaunchUpdate(repairToChange);
                    };
                    MenuPageAction action = new MenuPageAction($"{field} (object {repairToChange.RepairId})", changeAction);
                    pageActions.Add(action);
                }
            }
            return pageActions;
        }

        /// <summary>
        /// Handles the process of switching between menu items.
        /// </summary>
        public override void SwitchingMenuItems()
        {
            bool select = false;
            ConsoleKeyInfo key;

            // Continue switching menu items until a selection is made.
            while (!select)
            {
                Clear();
                Console.CursorVisible = false;
                ShowMenu();
                key = Console.ReadKey(true);
                ProcessKeyPress(this, key, ref select);
            }
        }

        /// <summary>
        /// Processes the key press event.
        /// </summary>
        protected override void ProcessKeyPress(MenuPage change, ConsoleKeyInfo key, ref bool select)
        {
            switch (key.Key)
            {
                case ConsoleKey.DownArrow or ConsoleKey.S:
                    change.IndexAction = IncrementIndex(change.IndexAction, change.MenuPageActions.Count);
                    break;
                case ConsoleKey.UpArrow or ConsoleKey.W:
                    change.IndexAction = DecrementIndex(change.IndexAction, change.MenuPageActions.Count);
                    break;

                // Perform individual actions when the enter key is pressed.
                case ConsoleKey.Enter:
                    PerformIndividualActions();
                    Clear();
                    Console.WriteLine("The changing was successful!");
                    Thread.Sleep(1000);
                    break;

                // Navigate back to the previous menu page when the backspace key is pressed.
                case ConsoleKey.Backspace:
                    MenuStack.StackMenuPage.Pop();                    
                    select = true;
                    break;

                // Exit the program when the escape key is pressed.
                case ConsoleKey.Escape:
                    DataStorage.StatusProgram = false;
                    select = true;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Displays the menu for changing repair properties.
        /// </summary>
        internal override void ShowMenu()
        {
            Console.WriteLine("To end the program, click Escape. To go back, click Backspace.");
            ShowMenuPage(MenuPageActions);
        }

        /// <summary>
        /// Performs individual actions based on the selected menu item.
        /// </summary>
        protected override void PerformIndividualActions()
        {
            base.PerformIndividualActions();
        }
    }
}
