﻿using DataProcessing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;

using Machine = DataProcessing.Machine;

namespace UIMenu.ChangePage
{
    /// <summary>
    /// Represents a base page for changing properties of objects.
    /// </summary>
    internal class ChangeObjectPage : MenuPage
    {
        // Event handler for page actions.
        public new delegate void PageActionEventHandler(object sender);

        // Event triggered when an action is activated.
        public new event PageActionEventHandler ActionActivated;

        // Title of the change object page.
        public readonly string _title = "Change objects.";

        // Index of the selected action.
        private int _indexOfSelectedActions;

        //Property.
        public override string? Title { get { return _title; } }
        public override int IndexAction
        {
            get { return _indexOfSelectedActions; }
            set { _indexOfSelectedActions = value; }
        }

        public override List<MenuPageAction>? MenuPageActions { get; }

        /// <summary>
        /// Starts the action associated with the selected menu item.
        /// </summary>
        public new void StartAction()
        {
            ActionActivated?.Invoke(this);
        }

        /// <summary>
        /// Shows the menu page.
        /// </summary>
        internal override void ShowMenu()
        {
            ShowMenuPage(MenuPageActions);
        }

        /// <summary>
        /// Handles the process of switching between menu items.
        /// </summary>
        public override void SwitchingMenuItems()
        {
            RequestMachineId();
            MenuStack.StackMenuPage.Push(new ChangeMachine());            
        }

        /// <summary>
        /// Requests the ID of the machine to be changed from the user.
        /// </summary>
        public static void RequestMachineId()
        {
            Clear();
            Console.Write($"Enter the ID of the machine in which you want to make changes ( from 0 to {DataStorage.ModifiedMachines.Count - 1} ):");
            int indexObjectToChange = SetCorrectValue();
            DataStorage.IndexObjectToChange = indexObjectToChange;
        }

        /// <summary>
        /// Sets the correct value entered by the user.
        /// </summary>
        private static int SetCorrectValue()
        {
            int value;
            while (!int.TryParse(Console.ReadLine(), out value) || Comparer<int>.Default.Compare(value, default) < 0 || Comparer<int>.Default.Compare(value, DataStorage.ModifiedMachines.Count) > 0)
            {
                Console.Write("Введенное значение некорректно! Попробуйте еще раз: ");
            }
            return value;
        }

        /// <summary>
        /// Launches the update process after changing object properties.
        /// </summary>
        protected static void LaunchUpdate(Data objectToChange)
        {
            objectToChange.Updated += AutoSaver.DataUpdateEventHandler;
            objectToChange.Update();
            objectToChange.Updated -= AutoSaver.DataUpdateEventHandler;
        }
    }
}
