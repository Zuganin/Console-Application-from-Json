﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UIMenu
{
    public class MenuStack
    {
        public static Stack<MenuPage> StackMenuPage = new Stack<MenuPage>();
       

        public void Push(MenuPage page)
        {
            StackMenuPage.Push(page);
        }

        public MenuPage Pop()
        {
            return StackMenuPage.Pop();
        }

        public MenuPage Peek()
        {
            return StackMenuPage.Peek();
        }

        public bool IsEmpty()
        {
            return StackMenuPage.Count == 0;
        }
        public static void NavigateTo(MenuPage page)
        {
            Console.WriteLine($"{page.Title}");
            page.SwitchingMenuItems();            
        }
    }
}
