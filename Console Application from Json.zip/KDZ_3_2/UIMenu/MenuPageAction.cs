﻿namespace UIMenu
{
    public class MenuPageAction
    {       
        public string Name {  get; }
        internal Action? Action { get; set; }

        internal MenuPageAction(string name, Action? MenuPageAction = null)
        {
            Name = name;
            Action = MenuPageAction ?? (() => { });
        }
        public void PageActionEnventHandler(object sender)
        {
            Action?.Invoke();
        }
    }
}
