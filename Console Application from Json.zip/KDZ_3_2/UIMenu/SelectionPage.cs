﻿using DataProcessing;
using UIMenu.ChangePage;
using UIMenu.TablePage;

namespace UIMenu
{
    public class SelectionPage : MenuPage
    {
        internal new delegate void PageActionEventHandler(object sender);

        internal new event  PageActionEventHandler ActionActivated;       

        private int _indexOfSelectedActions;

        public override string? Title { get { return _title; } }
        public override int IndexAction
        {
            get { return _indexOfSelectedActions; }
            set { _indexOfSelectedActions = value; }
        }

        public MenuPage[] MenuPages { get;  set; }
        public override List<MenuPageAction>? MenuPageActions {  get;  }
        
        public void StartAction()
        {
            ActionActivated?.Invoke(this);
        }


        public SelectionPage()
        {
            MenuPages = CreateMenuPage();
            MenuPageActions = CreateMenuActions();
        }

        private MenuPage[] CreateMenuPage()
        {
            MenuPage[] menuPages = new MenuPage[3];
            menuPages[0] = new TableObjectsPage();
            menuPages[1] = new SortPage();
            menuPages[2] = new ChangeObjectPage();
            return menuPages;
        }        
        private List<MenuPageAction> CreateMenuActions()
        {
            List<MenuPageAction> pageActions = new List<MenuPageAction>();
            Action inputAbsolutFilePath= () =>
            {
                SetCorrectListObjects();

            };
            MenuPageAction menuInputAbsolutFilePath = new MenuPageAction($"{new InputFilePathPage().Title}", inputAbsolutFilePath);
            pageActions.Add(menuInputAbsolutFilePath);
            foreach (MenuPage page in MenuPages)
            {
                Action action = () => 
                { 
                    if(DataStorage.ModifiedMachines == null)
                    {
                        Console.WriteLine("You haven't entered the data yet. After entering these functions, they will open!");
                        Thread.Sleep(2500);
                    }
                    else
                    {
                        MenuStack.StackMenuPage.Push(page);
                    }                     
                };
                MenuPageAction menuAction = new MenuPageAction($"{page.Title}", action);
                pageActions.Add(menuAction);
            }
            Action aexit = () => { DataStorage.StatusProgram = false; };
            MenuPageAction pageAction = new MenuPageAction($"Exit", aexit);
            pageActions.Add(pageAction);
            return pageActions;
        }

        private static void SetCorrectListObjects()
        {
            bool control = false;
            do
            {
                try
                {
                    InputFilePathPage.InputAbsoluteFilePath();
                    List<Machine> listobj = JsonParser.GetListMachineObjects();
                    CheckingData.CheckCorrectFile(listobj);
                    DataStorage.ModifiedMachines = listobj;
                    control = true;
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine($"{ex.Message}");
                    Console.WriteLine("Try again!");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{ex.Message}");
                    Console.WriteLine("Try again!");
                }
            } while (!control);
        }
    }
}
