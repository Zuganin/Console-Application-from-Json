﻿using DataProcessing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UIMenu
{
    public class WelcomePage : MenuPage
    {
        internal new delegate void PageActionEventHandler(object sender);

        internal new event PageActionEventHandler? ActionActivated;

        private readonly string? _title = $"{Environment.UserName} you are welcomed by the start menu of the Control homework in C#,\n"
            +$"by student BPI-2311 Zenin Vadim Andreevich enjoy your use!!!";
        private int _indexOfSelectedActions;
        public override List<MenuPageAction>? MenuPageActions { get; }
        public override string? Title { get { return _title; } }
        public override int IndexAction
        {
            get { return _indexOfSelectedActions; }
            set { _indexOfSelectedActions = value; }
        }
        public WelcomePage()
        {
            MenuPageActions = CreateAction();
        }

        private static List<MenuPageAction> CreateAction()
        {
            List<MenuPageAction> pageActions = new();
            Action continueAction = () => 
            {
                MenuStack.StackMenuPage.Push(new SelectionPage());
            };
            MenuPageAction action1 = new($"Continue.", continueAction);
            pageActions.Add(action1);
            Action exitAction = () =>
            {
                DataStorage.StatusProgram = false;
            };
            MenuPageAction action2 = new($"Exit.", exitAction);
            pageActions.Add(action2);
            return pageActions;
        }

        public new void StartAction()
        {
            ActionActivated?.Invoke(this);
        }
        protected override void ProcessKeyPress(MenuPage change, ConsoleKeyInfo key, ref bool select)
        {
            switch (key.Key)
            {
                case ConsoleKey.DownArrow or ConsoleKey.S:
                    change.IndexAction = IncrementIndex(change.IndexAction, change.MenuPageActions.Count);
                    break;
                case ConsoleKey.UpArrow or ConsoleKey.W:
                    change.IndexAction = DecrementIndex(change.IndexAction, change.MenuPageActions.Count);
                    break;
                case ConsoleKey.Enter:
                    PerformIndividualActions();
                    select = true;
                    break;                
                default:
                    break;
            }
        }
        internal override void ShowMenu()
        {
            Console.WriteLine(Title);
            ShowMenuPage(MenuPageActions);
        }

        protected override void PerformIndividualActions()
        {
            base.PerformIndividualActions();
        }
    }
}
