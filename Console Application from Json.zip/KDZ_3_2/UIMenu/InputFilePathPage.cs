﻿using DataProcessing;

namespace UIMenu
{
    internal class InputFilePathPage : MenuPage
    {
        internal new delegate void PageActionEventHandler(object sender);

        internal new event PageActionEventHandler? ActionActivated;

        internal new readonly string? _title = "Input file path.";
        private int _indexOfSelectedActions;
        public override List<MenuPageAction>? MenuPageActions { get; }

        public override string? Title { get { return _title; } }

        public override int IndexAction
        {
            get { return _indexOfSelectedActions; }
            set { _indexOfSelectedActions = value; }
        }
        
        public static void InputAbsoluteFilePath()
        {
            Console.WriteLine("Enter the absolute path to the file:");
            Console.CursorVisible = true;
            string path = Console.ReadLine();            
            while (!CheckingData.CheckFilePath(path))
            {
                Console.WriteLine("It looks like there is no such file. Try again!");
                path = Console.ReadLine();
            }            
            DataStorage.FilePath = path;
            DataStorage.TempFilePath = CheckingData.SetTempFilePath(path);
            Console.CursorVisible = false;
        }
        internal override void ShowMenu()
        {
            Console.WriteLine(Title);
            ShowMenuPage(MenuPageActions);
        }
    }
}
