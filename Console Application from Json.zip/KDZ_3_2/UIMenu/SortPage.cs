﻿using DataProcessing;
using System.Collections.Concurrent;

namespace UIMenu
{
    public class SortPage : MenuPage
    {
        internal new delegate void PageActionEventHandler(object sender);

        internal new event PageActionEventHandler? ActionActivated;

        private new readonly string? _title = "Sorting objects.";
        private int _indexOfSelectedActions;
        private static bool Reverse {  get; set; }
        public override List<MenuPageAction>? MenuPageActions { get; }
        public override string? Title { get { return _title; } }
        public override int IndexAction
        {
            get { return _indexOfSelectedActions; }
            set { _indexOfSelectedActions = value; }
        }

        public new void StartAction()
        {
            ActionActivated?.Invoke(this);
        }

        public SortPage()
        {
            MenuPageActions = CreateAction();
        }

        private static List<MenuPageAction> CreateAction()
        {
            List<MenuPageAction> pageActions = new();
            foreach(var field in Enum.GetValues(typeof(Machine.FieldsToSort)))
            {

                Action changeAction = () =>
                {
                   DataManager.SortData(DataStorage.ModifiedMachines, (Machine.FieldsToSort)field ,Reverse);
                };
                MenuPageAction action = new MenuPageAction($"{field} ", changeAction);
                pageActions.Add(action);
            }
            return pageActions;
        }
        public override void SwitchingMenuItems()
        {
            bool select = false;
            ConsoleKeyInfo key;

            while (!select)
            {
                Clear();
                Console.CursorVisible = false;
                PrintReverseStatus();
                ShowMenu();
                key = Console.ReadKey(true);
                ProcessKeyPress(this, key, ref select);
            }
        }
        protected override void ProcessKeyPress(MenuPage change, ConsoleKeyInfo key, ref bool select)
        {
            switch (key.Key)
            {
                case ConsoleKey.DownArrow or ConsoleKey.S:
                    change.IndexAction = IncrementIndex(change.IndexAction, change.MenuPageActions.Count);
                    break;
                case ConsoleKey.UpArrow or ConsoleKey.W:
                    change.IndexAction = DecrementIndex(change.IndexAction, change.MenuPageActions.Count);
                    break;
                case ConsoleKey.RightArrow:
                    ChangeReverseIndex();
                    break;
                case ConsoleKey.LeftArrow:
                    ChangeReverseIndex();                    
                    break;
                case ConsoleKey.Enter:
                    PerformIndividualActions();
                    Clear();
                    Console.WriteLine("The sorting was successful!");
                    Thread.Sleep(1000);
                    select = true;
                    break;
                case ConsoleKey.Backspace:
                    MenuStack.StackMenuPage.Pop();
                    select = true;
                    break;
                case ConsoleKey.Escape:
                    DataStorage.StatusProgram = false;
                    select = true;
                    break;
                default:
                    break;
            }
        }

        private static void ChangeReverseIndex()
        {
            Reverse = Reverse == true ? Reverse = false : true;
        }

        protected override void PerformIndividualActions()
        {
            ActionActivated += MenuPageActions[IndexAction].PageActionEnventHandler;
            Clear();
            StartAction();
            ActionActivated -= MenuPageActions[IndexAction].PageActionEnventHandler;
        }

        internal void PrintReverseStatus()
        {
            Console.WriteLine("To go back, click Backspace.");
            Console.Write("Sorting status");
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine($"({(Reverse == false ? "ascending order" : "descending order")})");
            Console.ResetColor();
            Console.WriteLine("Sort by the following fields");            
        }       
              
    }
}
