﻿using DataProcessing;
using DataProcessing.Interfaces;
using System.Data;
using static DataProcessing.Machine;

namespace UIMenu.TablePage
{
    /// <summary>
    /// Represents a table page for displaying repair data.
    /// </summary>
    internal class TableRepair : TableObjectsPage, ITableCreator
    {
        public new readonly string? _title = "View the list of objects.";


        private int _indexOfSelectedActions;
        public override List<MenuPageAction>? MenuPageActions { get; }

        public override string? Title { get { return _title; } }
        public override int IndexAction
        {
            get { return _indexOfSelectedActions; }
            set { _indexOfSelectedActions = value; }
        }

        /// <summary>
        /// Constructor for TableRepair class.
        /// Initializes menu page actions based on the number of objects.
        /// </summary>
        public TableRepair()
        {
            MenuPageActions = CreateActions(CountObjectsForTable);
        }

        /// <summary>
        /// Creates actions for the menu page based on the number of objects.
        /// </summary>
        /// <param name="countObjects">Number of objects.</param>
        /// <returns>List of menu page actions.</returns>
        private static List<MenuPageAction> CreateActions(int countObjects)
        {
            List<MenuPageAction> pageActions = new();

            // Iterates through all fields and creates actions for each field.
            foreach (var field in Enum.GetValues(typeof(Repair.FieldsToTable)))
            {
                string? fieldName = field.ToString();
                Action changeAction = () =>
                {
                    WriteData(countObjects, fieldName);
                };
                MenuPageAction action = new MenuPageAction($"{field}", changeAction);
                pageActions.Add(action);
            }
            return pageActions;
        }

        /// <summary>
        /// Writes repair data to the console based on the selected field.
        /// </summary>
        /// <param name="countObjects">Number of objects to display.</param>
        /// <param name="fieldName">Name of the field to display.</param>
        private static void WriteData(int countObjects, string? fieldName)
        {
            // Writes table columns with the specified field names.
            Console.Write(ITableCreator.CreateTableColumns(FieldsToSort.MachineId.ToString(), fieldName));

            // Iterates through each object and its repairs, then writes data for the specified field.
            for (int i = 0; i < countObjects; i++)
            {
                Machine machine = DataStorage.ModifiedMachines[i];
                for (int j = 0; j < machine.Repairs.Count; j++)
                {
                    Repair? repair = machine.Repairs[j];
                    string? fieldValue = ValueFieldToString(fieldName, repair);
                    Console.Write(repair.CreateTable(j, machine.Repairs.Count, machine.MachineId.ToString(), fieldValue));
                }
            }
        }

        /// <summary>
        /// Converts the value of a field to its string representation.
        /// </summary>
        /// <param name="fieldName">Name of the field.</param>
        /// <param name="repair">Repair object.</param>
        /// <returns>String representation of the field value.</returns>
        private static string? ValueFieldToString(string? fieldName, Repair repair)
        {
            // If the field is RepairDate, parses it to string format.
            if (fieldName == "RepairDate")
            {
                return ParseDateTimeToString(fieldName, repair);
            }

            // Gets the string representation of the field value.
            return repair.GetType().GetProperty(fieldName)?.GetValue(repair)?.ToString();
        }

        /// <summary>
        /// Parses DateTime field to string.
        /// </summary>
        /// <param name="fieldName">Name of the field.</param>
        /// <param name="repair">Repair object.</param>
        /// <returns>String representation of the DateTime field.</returns>
        private static string ParseDateTimeToString(string? fieldName, Repair repair)
        {
            DateTime? dateTime = (DateTime)repair?.GetType()?.GetProperty(fieldName)?.GetValue(repair);
            string? dateString = dateTime.ToString();
            var date = dateString?.Split(" ");
            return date[0];
        }

        /// <summary>
        /// Processes the key press for navigation.
        /// </summary>
        /// <param name="change">MenuPage to change.</param>
        /// <param name="key">Pressed console key.</param>
        /// <param name="select">Flag indicating whether an action is selected.</param>
        protected override void ProcessKeyPress(MenuPage change, ConsoleKeyInfo key, ref bool select)
        {
            switch (key.Key)
            {
                case ConsoleKey.RightArrow or ConsoleKey.D:
                    change.IndexAction = IncrementIndex(change.IndexAction, change.MenuPageActions.Count);
                    break;
                case ConsoleKey.LeftArrow or ConsoleKey.S:
                    change.IndexAction = DecrementIndex(change.IndexAction, change.MenuPageActions.Count);
                    break;

                // Starts the individual action.
                case ConsoleKey.Enter:
                    PerformIndividualActions();                    
                    select = true;
                    break;

                // Goes back to the previous menu.
                case ConsoleKey.Backspace:
                    MenuStack.StackMenuPage.Pop();
                    select = true;
                    break;

                // Exits the program.
                case ConsoleKey.Escape:
                    DataStorage.StatusProgram = false;
                    select = true;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Switches between menu items based on user input.
        /// </summary>
        public override void SwitchingMenuItems()
        {
            bool select = false;
            ConsoleKeyInfo key;

            // Loops until the user selects an action or goes back.
            while (!select)
            {
                Clear();
                Console.CursorVisible = false;
                Console.WriteLine("To go back, click Backspace.");
                PerformIndividualActions();

                // Displays menu actions and handles user input.
                key = Console.ReadKey(true);

                // Processes user input.
                ProcessKeyPress(this, key, ref select);
            }
        }

        /// <summary>
        /// Performs individual actions for the menu.
        /// </summary>
        protected override void PerformIndividualActions()
        {
            // Subscribes to the selected action's event handler, starts the action, and then unsubscribes.
            ActionActivated += MenuPageActions[IndexAction].PageActionEnventHandler;
            StartAction();
            ActionActivated -= MenuPageActions[IndexAction].PageActionEnventHandler;
        }
    }
}
