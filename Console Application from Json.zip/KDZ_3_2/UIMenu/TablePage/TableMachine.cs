﻿using DataProcessing;


using DataProcessing.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static DataProcessing.Machine;

namespace UIMenu.TablePage
{
    /// <summary>
    /// Represents a table page for displaying machine data.
    /// </summary>
    internal class TableMachine : TableObjectsPage, ITableCreator
    {
        // Properties.
        public new readonly string? _title = "View the list of objects.";
        private int _indexOfSelectedActions;
        public override List<MenuPageAction>? MenuPageActions { get; }
        public override string? Title { get { return _title; } }
        public override int IndexAction
        {
            get { return _indexOfSelectedActions; }
            set { _indexOfSelectedActions = value; }
        }

        /// <summary>
        /// Constructor for TableMachine class.
        /// Initializes menu page actions based on the number of objects.
        /// </summary>
        public TableMachine()
        {
            MenuPageActions = CreateActions(CountObjectsForTable);
        }

        /// <summary>
        /// Creates actions for the menu page based on the number of objects.
        /// </summary>
        /// <param name="countObjects">Number of objects.</param>
        /// <returns>List of menu page actions.</returns>
        private static List<MenuPageAction> CreateActions(int countObjects)
        {
            List<MenuPageAction> pageActions = new();

            // Iterates through all fields except MachineId and creates actions for each field.
            foreach (var field in Enum.GetValues(typeof(FieldsToSort)))
            {
                string? fieldName = field.ToString();
                if (fieldName != "MachineId")
                {
                    // Action to change displayed data based on the selected field.
                    Action changeAction = () =>
                    {
                        WriteData(countObjects, fieldName);
                    };

                    // Creates a menu page action for the field.
                    MenuPageAction action = new MenuPageAction($"{field}", changeAction);
                    pageActions.Add(action);
                }
            }
            return pageActions;
        }

        /// <summary>
        /// Writes data to the console based on the selected field.
        /// </summary>
        /// <param name="countObjects">Number of objects to display.</param>
        /// <param name="fieldName">Name of the field to display.</param>
        private static void WriteData(int countObjects, string? fieldName)
        {
            // Writes table columns with the specified field names.
            Console.Write(ITableCreator.CreateTableColumns(FieldsToSort.MachineId.ToString(), fieldName));

            // Iterates through each object and writes data for the specified field.
            for (int i = 0; i < countObjects; i++)
            {
                Machine machine = DataStorage.ModifiedMachines[i];
                string? fieldValue = ValueFieldToString(fieldName, machine);
                Console.Write(machine.CreateTable(machine.MachineId.ToString(), fieldValue));
            }
        }

        /// <summary>
        /// Switches between menu items based on user input.
        /// </summary>
        public override void SwitchingMenuItems()
        {
            bool select = false;
            ConsoleKeyInfo key;

            // Loops until the user selects an action or goes back.
            while (!select)
            {
                Clear();
                Console.CursorVisible = false;
                Console.WriteLine("To view the Repairs, click enter. To go back, click Backspace.");
                PerformIndividualActions();

                // Displays menu actions and handles user input.
                key = Console.ReadKey(true);

                // Processes user input.
                ProcessKeyPress(this, key, ref select);
            }
        }

        /// <summary>
        /// Converts the value of a field to its string representation.
        /// </summary>
        /// <param name="fieldName">Name of the field.</param>
        /// <param name="machine">Machine object.</param>
        /// <returns>String representation of the field value.</returns>
        private static string? ValueFieldToString(string? fieldName, Machine machine)
        {
            return machine.GetType().GetProperty(fieldName)?.GetValue(machine)?.ToString();
        }

        /// <summary>
        /// Processes the key press for navigation.
        /// </summary>
        /// <param name="change">MenuPage to change.</param>
        /// <param name="key">Pressed console key.</param>
        /// <param name="select">Flag indicating whether an action is selected.</param>
        protected override void ProcessKeyPress(MenuPage change, ConsoleKeyInfo key, ref bool select)
        {
            switch (key.Key)
            {
                case ConsoleKey.RightArrow or ConsoleKey.D:
                    change.IndexAction = IncrementIndex(change.IndexAction, change.MenuPageActions.Count);
                    break;
                case ConsoleKey.LeftArrow or ConsoleKey.S:
                    change.IndexAction = DecrementIndex(change.IndexAction, change.MenuPageActions.Count);
                    break;

                // Starts the repairs table menu.
                case ConsoleKey.Enter:
                    StartRepairsTable();                    
                    select = true;
                    break;

                // Goes back to the previous menu.
                case ConsoleKey.Backspace:
                    MenuStack.StackMenuPage.Pop();
                    select = true;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Starts the repairs table menu.
        /// </summary>
        protected void StartRepairsTable()
        {
            new TableRepair().SwitchingMenuItems();
        }

        /// <summary>
        /// Performs individual actions for the menu.
        /// </summary>
        protected override void PerformIndividualActions()
        {
            // Subscribes to the selected action's event handler, starts the action, and then unsubscribes.
            ActionActivated += MenuPageActions[IndexAction].PageActionEnventHandler;
            StartAction();
            ActionActivated -= MenuPageActions[IndexAction].PageActionEnventHandler;
        }

    }
}
