﻿using DataProcessing;
using System.Text.RegularExpressions;

namespace UIMenu.TablePage
{
    /// <summary>
    /// Represents a menu page with actions related to viewing a list of objects.
    /// </summary>
    internal class TableObjectsPage : MenuPage
    {
        /// <summary>
        /// Title of the menu page.
        /// </summary>
        public new readonly string? _title = "View the list of objects.";

        public static int CountObjectsForTable {  get; set; }

        private int _indexOfSelectedActions;
        public override List<MenuPageAction>? MenuPageActions { get; }

        public override string? Title { get { return _title; } }
        public override int IndexAction
        {
            get { return _indexOfSelectedActions; }
            set { _indexOfSelectedActions = value; }
        }

        /// <summary>
        /// Performs switching menu items.
        /// </summary>
        public override void SwitchingMenuItems()
        {            
            RequestNumberObjects(DataStorage.ModifiedMachines);
            new TableMachine().SwitchingMenuItems();                        
        }

        /// <summary>
        /// Performs individual actions.
        /// </summary>
        protected override void PerformIndividualActions()
        {
            ActionActivated += MenuPageActions[IndexAction].PageActionEnventHandler;
            StartAction();
            ActionActivated -= MenuPageActions[IndexAction].PageActionEnventHandler;
        }

        /// <summary>
        /// Requests the number of objects to display.
        /// </summary>
        public static void RequestNumberObjects(List<Machine> AllObjects)
        {
            Console.Write($"Enter the number of objects to be viewed ( >= 1 and <= {AllObjects.Count} ):");
            int count = SetCorrectValue();
            CountObjectsForTable =  count;
        }

        /// <summary>
        /// Sets the correct value for the number of objects.
        /// </summary>
        private static int SetCorrectValue()
        {
            int value;
            while (!int.TryParse(Console.ReadLine(), out value) || Comparer<int>.Default.Compare(value, default) <= 0 || Comparer<int>.Default.Compare(value, DataStorage.ModifiedMachines.Count) > 0)
            {
                Console.Write("The entered value is incorrect! Try again: ");
            }
            return value;
        }        
    }
}
