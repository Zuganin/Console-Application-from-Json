Before launching, it is recommended to open the test one.json file and view the available fields for more convenient data handling

After launching the application, you must first enter the absolute path to a text file or a file containing the same fields. The Backspace keys are used to switch between the menu pages.  
The program uses an autosave if the user changed some fields in the file with a difference of less than 15 seconds (this was the tk). The file is saved to a folder...\net 6.0\"your file name"_tmp.json