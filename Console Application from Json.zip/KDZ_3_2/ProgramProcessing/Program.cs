﻿using DataProcessing;
using UIMenu;

namespace ProgramProcessing
{
    internal class Program
    {
        static MenuStack menuStack = new MenuStack();
        static void Main(string[] args)
        {          

            // Пример создания и использования страниц меню
            WelcomePage page1 = new();
            menuStack.Push(page1);

            do 
            {
                try
                {
                    menuStack.Peek().SwitchingMenuItems();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{ex.Message}");
                }                
                
            } while(DataStorage.StatusProgram);
            MenuPage.Exit();           

        }
        
    }
}

