﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DataProcessing
{
    /// <summary>
    /// Provides methods for checking data integrity and file paths.
    /// </summary>
    public class CheckingData
    {
        /// <summary>
        /// Checks if the specified file path exists.
        /// </summary>
        /// <param name="path">The file path to check.</param>
        /// <returns>True if the file exists; otherwise, false.</returns>
        public static bool CheckFilePath(string path)
        {
            // Check if the specified file path exists.
            if (!File.Exists(path))
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Sets a temporary file path based on the original file path.
        /// </summary>
        /// <param name="path">The original file path.</param>
        /// <returns>The temporary file path.</returns>
        public static string SetTempFilePath(string path)
        {
            // Set a temporary file path by appending "_tmp.json" to the original file name.
            string newNameFile = $"{Path.GetFileNameWithoutExtension(path)}_tmp.json";
            return Path.Combine(Path.GetDirectoryName(path), newNameFile);
        }

        /// <summary>
        /// Checks the correctness of the data format in a list of machines and their repairs.
        /// </summary>
        /// <param name="machines">The list of machines to check.</param>
        public static void CheckCorrectFile(List<Machine> machines)
        {
            // Check each machine and its repairs for correct data format.
            foreach (Machine machine in machines)
            {
                if (machine.MachineId == 0 || machine.Brand == null || machine.Model == null || machine.Year == 0 || machine.Price == 0 || machine.Repairs == null)
                    throw new ArgumentNullException("Incorrect file format. Try to specify another file!");
                foreach (Repair repair in machine.Repairs)
                {
                    if (repair.RepairId == null || repair.Issue == null || repair.RepairCost == 0 || repair.Technician == null || repair.RepairDate == DateTime.MinValue)
                        throw new ArgumentNullException("Incorrect file format. Try to specify another file!");
                }
            }
        }
    }
}
