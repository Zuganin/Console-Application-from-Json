﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataProcessing
{
    public class CheckStatusRepairEventArgs : EventArgs
    {
        public string Message { get; set; }
        public CheckStatusRepairEventArgs() { }
        public CheckStatusRepairEventArgs(string message)
        {
            Message = message; 
        }

    }
}
