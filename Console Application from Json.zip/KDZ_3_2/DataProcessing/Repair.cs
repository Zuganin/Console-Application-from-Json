﻿using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using DataProcessing.Interfaces;


namespace DataProcessing
{
    /// <summary> ///
    /// Represents a repair object containing information about a machine repair.
    /// </summary> ///
    public class Repair : Data, ITableCreator
    {
        // Event handler delegate for checking repair status.
        public delegate void CheckStatusRepairEventHandler(object sender, CheckStatusRepairEventArgs eventArgs);

        // Event triggered to check repair status.
        public event EventHandler? CheckStatusRepair;

        /// <summary>
        /// Triggers the CheckStatusRepair event to check the repair status.
        /// </summary>
        public void CheckStatus()
        {
            CheckStatusRepair?.Invoke(this, new CheckStatusRepairEventArgs());
        }

        // Private fields representing repair properties.
        private string? _repairId;
        private string? _issue;
        private double _repairCost;
        private string? _technician;
        private bool _isFixed;
        private DateTime _repairDate;

        // JSON property names for serialization.
        [JsonPropertyName("repair_id")]
        public string RepairId { get => _repairId; set => _repairId = value; }

        [JsonPropertyName("issue")]
        public string Issue { get => _issue; set => _issue = value; }

        [JsonPropertyName("repair_cost")]
        public double RepairCost { get => _repairCost; set => _repairCost = value; }

        [JsonPropertyName("technician")]
        public string Technician { get => _technician; set => _technician = value; }

        [JsonPropertyName("is_fixed")]
        public bool IsFixed { get => _isFixed; set => _isFixed = value; }

        [JsonPropertyName("repair_date")]
        public DateTime RepairDate { get => _repairDate; set => _repairDate = value; }

        /// <summary>
        /// Serializes a Repair object to JSON format.
        /// </summary>
        /// <param name="repairs">The Repair object to serialize.</param>
        /// <returns>The serialized JSON string.</returns>
        public static string ToJSON(Repair repairs)
        {
            string json = JsonSerializer.Serialize(repairs);
            return json;
        }

        // Enumerations for table creation and field modification.
        public enum FieldsToTable
        {
            RepairId = 1,
            Issue,
            RepairCost,
            Technician,
            IsFixed,
            RepairDate
        }

        public enum FieldsToChange
        {
            Issue = 1,
            RepairCost,
            Technician,
            IsFixed,
            RepairDate
        }

        /// <summary>
        /// Initiates the process of changing a repair attribute by prompting the user for input.
        /// </summary>
        /// <param name="field">The field to change.</param>
        public void ChangeRepair(FieldsToChange field)
        {
            PrintFieldVAlue(field);
            SetValueField(field);
        }

        /// <summary>
        /// Prints the current value of the specified field and prompts the user for the new value.
        /// </summary>
        /// <param name="field">The field to print.</param>
        private void PrintFieldVAlue(FieldsToChange field)
        {
            string fieldRepair = field.ToString();
            string fieldValue = fieldRepair switch
            {
                "Issue" => Issue.ToString(),
                "RepairCost" => RepairCost.ToString(),
                "Technician" => Technician.ToString(),
                "IsFixed" => IsFixed.ToString(),
                "RepairDate" => RepairDate.ToString(),
                _ => throw new ArgumentException(),
            };
            Console.WriteLine($"Enter a value for the field to be modified ({fieldValue})");
        }

        /// <summary>
        /// Sets the value of the specified field based on user input.
        /// </summary>
        /// <param name="field">The field to set.</param>
        private void SetValueField(FieldsToChange field)
        {
            var fieldDictionary = new Dictionary<FieldsToChange, Action>
            {
                { FieldsToChange.Issue, () => Issue = SetCorrectValue<string>() },
                { FieldsToChange.RepairCost,() => RepairCost = SetCorrectValue<double>() },
                { FieldsToChange.Technician, () => Technician = SetCorrectValue<string>() },
                { FieldsToChange.IsFixed, () => IsFixed = SetCorrectValue<bool>() },
                { FieldsToChange.RepairDate, () => RepairDate = SetCorrectValue<DateTime>() }
            };

            // Check if the specified field is supported.
            if (!fieldDictionary.ContainsKey(field))
                throw new ArgumentException();

            // Invoke the corresponding action for the specified field.
            fieldDictionary[field].Invoke();
        }

        /// <summary>
        /// Parses and validates user input to ensure it matches the specified type.
        /// </summary>
        /// <typeparam name="T">The type to parse the input into.</typeparam>
        /// <returns>The parsed and validated value.</returns>
        private static T SetCorrectValue<T>()
        {
            T value;
            while (!TryParseValue(Console.ReadLine(), out value) || Comparer<T>.Default.Compare(value, default) < 0 || value == null)
            {
                Console.Write("The entered value is incorrect! Try again: ");
            }
            return value;
        }

        /// <summary>
        /// Attempts to parse the input string into the specified type.
        /// </summary>
        /// <typeparam name="T">The type to parse the input into.</typeparam>
        /// <param name="input">The input string to parse.</param>
        /// <param name="value">The parsed value if parsing was successful.</param>
        /// <returns>True if parsing was successful, otherwise false.</returns>
        private static bool TryParseValue<T>(string input, out T value)
        {
            try
            {
                input = Regex.Unescape(input);

                // Check for special characters.
                if (input.Any(c => char.IsControl(c)))
                {
                    value = default;
                    return false;
                }
                value = (T)Convert.ChangeType(input, typeof(T));
                return true;
            }
            catch (FormatException)
            {
                value = default;
                return false;
            }
        }

        /// <summary>
        /// Creates a formatted table representing repair data for a specific repair index.
        /// </summary>
        /// <param name="indexRepair">The index of the repair.</param>
        /// <param name="allRepairs">The total number of repairs.</param>
        /// <param name="columnNames">The column names for the table.</param>
        /// <returns>A formatted string representing the repair data table.</returns>
        public string CreateTable(int indexRepair, int allRepairs, params string[] columnNames)
        {
            // Calculate column width based on console window width.
            int windowWidth = Console.WindowWidth - 4;

            int numColumns = columnNames.Length;
            int columnWidth = windowWidth / numColumns;

            // Initialize table and separator strings.
            string? table = null;
            string separator = "┼";

            // Generate separator based on repair index, total repairs, number of columns, and column width.
            separator = ITableRepairCreator.GetSeparatorsForRerpairsTable(indexRepair, allRepairs, numColumns, columnWidth, separator);

            // Append column headers to the table.
            table += "\n│";
            table = ITableRepairCreator.GetValueRepairsTable(indexRepair, columnNames, columnWidth, table);

            // Return the formatted table string along with the separator.
            return table + "\n" + separator;
        }

        /// <summary>
        /// Constructor for creating a new Repair object with randomly generated data.
        /// </summary>
        public Repair()
        {
            // Initialize a random number generator.
            Random random = new Random();

            // Generate random values for the repair properties.
            _repairId = GenerateRandomString(8);
            _issue = GenerateRandomIssue();
            _repairCost = random.NextDouble() * 1000; 
            _technician = GenerateRandomTechnician();
            _isFixed = random.Next(2) == 0;
            _repairDate = DateTime.Now.AddDays(-random.Next(365)); 
        }

        /// <summary>
        /// Generates a random alphanumeric string of specified length.
        /// </summary>
        /// <param name="length">The length of the random string to generate.</param>
        /// <returns>A randomly generated alphanumeric string.</returns>
        private string GenerateRandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            Random random = new Random();
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        /// <summary>
        /// Generates a random issue description.
        /// </summary>
        /// <returns>A randomly selected issue description.</returns>
        private string GenerateRandomIssue()
        {
            string[] issues = { "Battery", "Screen", "Software", "Hardware", "Network", "Other" };
            Random random = new Random();
            return issues[random.Next(issues.Length)];
        }

        /// <summary>
        /// Generates a random technician name.
        /// </summary>
        /// <returns>A randomly selected technician name.</returns>
        private string GenerateRandomTechnician()
        {
            string[] technicians = { "John", "Jane", "Timoxa", "Dimas", "Kostyan" , "Ivan", "Maks", "Nicitos", "Denchik", "Antoxa", "Vova"};
            Random random = new Random();
            return technicians[random.Next(technicians.Length)];
        }
    }
}
