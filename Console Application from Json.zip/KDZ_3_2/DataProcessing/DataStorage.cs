﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataProcessing
{
    /// <summary>
    /// This class holds static properties for storing various data related to the program.
    /// </summary>
    public class DataStorage
    {
        /// <summary>
        /// Gets or sets the list of modified machines.
        /// </summary>
        public static List<Machine>? ModifiedMachines { get; set; }

        /// <summary>
        /// Gets or sets the index of the object to change.
        /// </summary>
        public static int IndexObjectToChange { get; set; }

        /// <summary>
        /// Gets or sets the file path.
        /// </summary>
        public static string FilePath { get; set; }

        /// <summary>
        /// Gets or sets the temporary file path.
        /// </summary>
        public static string TempFilePath { get; set; }

        /// <summary>
        /// Gets or sets the status of the program.
        /// </summary>
        public static bool StatusProgram { get; set; } = true;
    }
}
