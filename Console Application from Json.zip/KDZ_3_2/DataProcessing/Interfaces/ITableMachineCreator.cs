﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataProcessing.Interfaces
{
    /// <summary>
    /// Internal interface for creating tables with a specific separator.
    /// </summary>
    internal interface ITableMachineCreator : ITableCreator
    {
        /// <summary>
        /// Creates a table with specified column names.
        /// </summary>
        /// <param name="columnNames">Array of column names.</param>
        /// <returns>The table string.</returns>
        string CreateTable(params string[] columnNames);

        /// <summary>
        /// Gets the full separator string for the table.
        /// </summary>
        /// <param name="numColumns">Number of columns in the table.</param>
        /// <param name="columnWidth">Width of each column.</param>
        /// <param name="separator">Separator string.</param>
        /// <returns>The full separator string.</returns>
        static string GetFullSeparator(int numColumns, int columnWidth, string separator)
        {
            for (int i = numColumns - 1; i >= 0; i--)
            {
                separator += new string('─', columnWidth) + "┼";
            }

            return separator;
        }

        /// <summary>
        /// Gets the table value.
        /// </summary>
        /// <param name="columnNames">Array of column names.</param>
        /// <param name="columnWidth">Width of each column.</param>
        /// <param name="table">Table string.</param>
        /// <returns>The table string.</returns>
        static string? GetTableValue(string[] columnNames, int columnWidth, string? table)
        {
            foreach (string columnName in columnNames)
            {
                table += PadCenter(columnName, columnWidth) + "│";
            }

            return table;
        }
    }
}
