﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataProcessing.Interfaces
{
    /// <summary>
    /// Interface for creating tables.
    /// </summary>
    public interface ITableCreator
    {
        /// <summary>
        /// Gets the table value.
        /// </summary>
        /// <param name="columnNames">Array of column names.</param>
        /// <param name="columnWidth">Width of each column.</param>
        /// <param name="table">Table string.</param>
        /// <returns>The table string.</returns>
        static string? GetTableValue(string[] columnNames, int columnWidth, string? table)
        {
            foreach (string columnName in columnNames)
            {
                table += PadCenter(columnName, columnWidth) + "│";
            }

            return table;
        }

        /// <summary>
        /// Creates table columns.
        /// </summary>
        /// <param name="columnNames">Array of column names.</param>
        /// <returns>The table string with columns.</returns>
        public static string CreateTableColumns(params string[] columnNames)
        {
            int windowWidth = Console.WindowWidth - 4;

            int numColumns = columnNames.Length;
            int columnWidth = windowWidth / numColumns;

            string table = "┼";
            string separator = "┼";

            for (int i = 0; i < numColumns; i++)
            {
                table += new string('─', columnWidth) + "┼";
                separator += new string('─', columnWidth) + "┼";
            }
            table += "\n│";

            foreach (string columnName in columnNames)
            {
                table += PadCenter(columnName, columnWidth) + "│";
            }

            return table + "\n" + separator;
        }

        /// <summary>
        /// Pads the string with spaces to center it in a given width.
        /// </summary>
        /// <param name="str">The string to pad.</param>
        /// <param name="width">The total width of the padded string.</param>
        /// <returns>The padded string.</returns>
        private protected static string PadCenter(string str, int width)
        {
            int spaces = width - str.Length;
            int padLeft = spaces / 2 + str.Length;
            return str.PadLeft(padLeft).PadRight(width);
        }

    }
}
