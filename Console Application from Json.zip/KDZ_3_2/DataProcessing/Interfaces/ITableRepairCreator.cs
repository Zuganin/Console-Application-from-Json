﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataProcessing.Interfaces
{
    /// <summary>
    /// Internal interface for creating repair tables with specific separators.
    /// </summary>
    internal interface ITableRepairCreator : ITableCreator
    {
        /// <summary>
        /// Creates a repair table with specified index and column names.
        /// </summary>
        /// <param name="indexRepair">Index of the repair.</param>
        /// <param name="columnNames">Array of column names.</param>
        /// <returns>The repair table string.</returns>
        string CreateTable(int indexRepair, params string[] columnNames);

        /// <summary>
        /// Gets the value for the repairs table.
        /// </summary>
        /// <param name="indexRepair">Index of the repair.</param>
        /// <param name="columnNames">Array of column names.</param>
        /// <param name="columnWidth">Width of each column.</param>
        /// <param name="table">Table string.</param>
        /// <returns>The table string.</returns>
        static string? GetValueRepairsTable(int indexRepair, string[] columnNames, int columnWidth, string? table)
        {
            if (indexRepair == 0)
            {
                table = GetTableValue(columnNames, columnWidth, table);
            }
            else
            {
                table = GetNotFullTable(columnNames, columnWidth, table);
            }

            return table;
        }

        /// <summary>
        /// Gets the separators for the repairs table.
        /// </summary>
        /// <param name="indexRepair">Index of the repair.</param>
        /// <param name="allRepairs">Total number of repairs.</param>
        /// <param name="numColumns">Number of columns in the table.</param>
        /// <param name="columnWidth">Width of each column.</param>
        /// <param name="separator">Separator string.</param>
        /// <returns>The separator string.</returns>
        static string GetSeparatorsForRerpairsTable(int indexRepair, int allRepairs, int numColumns, int columnWidth, string separator)
        {
            if (indexRepair == allRepairs - 1)
            {
                separator = GetFullSeparator(numColumns, columnWidth, separator);
            }
            else
            {
                separator = GetNotFullSeparator(numColumns, columnWidth, separator);
            }

            return separator;
        }

        /// <summary>
        /// Gets the table string for a non-full repair table.
        /// </summary>
        private static string? GetNotFullTable(string[] columnNames, int columnWidth, string? table)
        {
            for (int j = 0; j < columnNames.Length; j++)
            {
                string columnName = columnNames[j];
                if (j == 0)
                {
                    table += PadCenter("", columnWidth) + "│";
                }
                else
                {
                    table += PadCenter(columnName, columnWidth) + "│";
                }
            }
            return table;
        }

        /// <summary>
        /// Gets the separator string for a non-full repair table.
        /// </summary>
        private static string GetNotFullSeparator(int numColumns, int columnWidth, string separator)
        {
            for (int i = 0; i < numColumns; i++)
            {
                if (i < numColumns / 2)
                {
                    separator += new string(' ', columnWidth) + "┼";
                }
                else
                {
                    separator += new string('─', columnWidth) + "┼";
                }
            }

            return separator;
        }

        /// <summary>
        /// Gets the separator string for a full repair table.
        /// </summary>
        private static string GetFullSeparator(int numColumns, int columnWidth, string separator)
        {
            for (int i = 0; i < numColumns; i++)
            {
                if (i < numColumns / 2)
                {
                    separator += new string('─', columnWidth) + "┼";
                }
                else
                {
                    separator += new string('─', columnWidth) + "┼";
                }
            }

            return separator;
        }
    }
}
