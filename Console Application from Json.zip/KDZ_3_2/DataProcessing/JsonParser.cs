﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;


namespace DataProcessing
{
    /// <summary>
    /// This class provides methods for parsing JSON data and writing data to a file.
    /// </summary>
    public class JsonParser
    {
        /// <summary>
        /// Reads JSON data from the file specified in the DataStorage class and deserializes it into a list of Machine objects.
        /// </summary>
        /// <returns>The list of Machine objects deserialized from the JSON data.</returns>
        public static List<Machine> GetListMachineObjects()
        {
            string json = File.ReadAllText(DataStorage.FilePath);
            List<Machine>? machineObjects = JsonSerializer.Deserialize<List<Machine>>(json);
            return machineObjects;
        }

        /// <summary>
        /// Serializes the provided list of Machine objects to JSON format and writes it to the specified file path.
        /// </summary>
        /// <param name="data">The list of Machine objects to serialize and write to the file.</param>
        /// <param name="filePath">The file path where the JSON data will be written.</param>
        public static void WriteDataInFile(List<Machine> data, string filePath)
        {
            string json = Machine.ToJSON(data);
            using FileStream stream = new FileStream(filePath, FileMode.Create);
            using StreamWriter sw = new StreamWriter(stream);
            sw.WriteLine(json);
        }
    }
}
