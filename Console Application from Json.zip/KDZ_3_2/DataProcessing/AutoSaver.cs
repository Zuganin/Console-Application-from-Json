﻿

namespace DataProcessing
{
    /// <summary>
    /// Provides functionality for automatically saving data based on update events.
    /// </summary>
    public class AutoSaver
    {
        /// <summary>
        /// Gets or sets the time of the last update.
        /// </summary>
        public static DateTime TimeUpdate { get; set; }

        /// <summary>
        /// Handles the data update event and triggers saving if the update interval is less than or equal to 15 seconds.
        /// </summary>
        /// <param name="sender">The event sender.</param>
        /// <param name="dataUpdate">The data update event arguments.</param>
        public static void DataUpdateEventHandler(object sender, DataUpdateEventArgs dataUpdate)
        {
            if ((dataUpdate.CurrentUpdateDateTime - TimeUpdate).TotalSeconds <= 15)
            {
                JsonParser.WriteDataInFile(DataStorage.ModifiedMachines, DataStorage.TempFilePath);
            }
            TimeUpdate = dataUpdate.CurrentUpdateDateTime;
        }
    }
}
