﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static DataProcessing.Machine;

namespace DataProcessing
{
    /// <summary>
    /// This static class provides methods for sorting data in a list of machines.
    /// </summary>
    public static class DataManager
    {
        /// <summary>
        /// Sorts the data list based on the specified field name and sorting direction.
        /// </summary>
        /// <param name="dataArray">The list of machines to sort.</param>
        /// <param name="fieldName">The field to sort by.</param>
        /// <param name="isReverse">True to sort in reverse order; otherwise, false.</param>
        public static void SortData(List<Machine> dataArray, FieldsToSort fieldName, bool isReverse)
        {
            if (isReverse)
            {
                dataArray.Sort(Comparer<Machine>.Create((obj1, obj2) => CompareTo(obj1, obj2, fieldName)));
                dataArray.Reverse();
            }
            else
            {
                dataArray.Sort(Comparer<Machine>.Create((obj1, obj2) => CompareTo(obj1, obj2, fieldName)));
            }                
        }

        /// <summary>
        /// Compares two Machine objects based on the specified field.
        /// </summary>
        /// <param name="object1">The first Machine object to compare.</param>
        /// <param name="object2">The second Machine object to compare.</param>
        /// <param name="fieldToCompare">The field to compare by.</param>
        /// <returns>The result of the comparison.</returns>
        private static int CompareTo(Machine object1, Machine object2, FieldsToSort fieldToCompare)
        {
            return fieldToCompare switch
            {
                FieldsToSort.MachineId => Comparer.DefaultInvariant.Compare(object1.MachineId, object2.MachineId),
                FieldsToSort.Brand => Comparer.DefaultInvariant.Compare(object1.Brand, object2.Brand),
                FieldsToSort.Model => Comparer.DefaultInvariant.Compare(object1.Model, object2.Model),
                FieldsToSort.Year => Comparer.DefaultInvariant.Compare(object1.Year, object2.Year),
                FieldsToSort.Price => Comparer.DefaultInvariant.Compare(object1.Price, object2.Price),
                FieldsToSort.IsReady => Comparer.DefaultInvariant.Compare(object1.IsReady, object2.IsReady),
            };
        }
    }
}
