﻿using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;

using DataProcessing.Interfaces;

namespace DataProcessing
{
    /// <summary>
    /// This class represents a machine and includes properties for its attributes, methods for JSON serialization/deserialization, event handling, status checking, and modification.
    /// </summary>
    public class Machine : Data, ITableMachineCreator
    {
        /// <summary>
        /// Occurs when the machine is updated.
        /// </summary>
        public event EventHandler<DataUpdateEventArgs>? Updated;

        // Private fields
        private int _machine_id;
        private string? _brand;
        private string? _model;
        private int _year;
        private double _price;
        private bool _isReady;
        private List<Repair>? _repairs;

        // Properties
        [JsonPropertyName("machine_id")]
        public int MachineId { get => _machine_id; set => _machine_id = value; }

        [JsonPropertyName("brand")]
        public string Brand { get => _brand; set => _brand = value; }

        [JsonPropertyName("model")]
        public string Model { get => _model; set => _model = value; }

        [JsonPropertyName("year")]
        public int Year { get => _year; set => _year = value; }

        [JsonPropertyName("price")]
        public double Price { get => _price; set => _price = value; }

        [JsonPropertyName("is_ready")]
        public bool IsReady { get => _isReady; set => _isReady = value; }

        [JsonPropertyName("repairs")]
        public List<Repair> Repairs
        {
            get => _repairs;
            set
            {
                _repairs = value;
                foreach (var pair in _repairs)
                {
                    pair.CheckStatusRepair += CheckStatusRepairEventHandler;
                }
            }
        }
        public Machine() { }

        /// <summary>
        /// Serializes the machine object to JSON format.
        /// </summary>
        /// <param name="machine">The machine object to serialize.</param>
        /// <returns>The JSON representation of the machine object.</returns>
        public static string ToJSON(Machine machine)
        {
            // JSON serialization options.
            var options = new JsonSerializerOptions()
            {
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
                WriteIndented = true
            };
            string json = JsonSerializer.Serialize(machine, options);
            return json;
        }

        /// <summary>
        /// Serializes a list of machine objects to JSON format.
        /// </summary>
        /// <param name="machines">The list of machine objects to serialize.</param>
        /// <returns>The JSON representation of the list of machine objects.</returns>
        public static string ToJSON(List<Machine> machines)
        {
            var options = new JsonSerializerOptions()
            {
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
                WriteIndented = true
            };
            string json = JsonSerializer.Serialize(machines, options);
            return json;
        }

        /// <summary>
        /// Handles the repair status change event and triggers status checking.
        /// </summary>
        /// <param name="sender">The event sender.</param>
        /// <param name="e">The event arguments.</param>
        public void CheckStatusRepairEventHandler(object? sender, EventArgs e)
        {
            TestAllRepairs();
        }
        

        /// <summary>
        /// Checks if all repairs are fixed and triggers the machine readiness change.
        /// </summary>
        private void TestAllRepairs()
        {
            bool AllRepairsFixed = true;
            foreach (Repair repair in Repairs)
            {
                if (!repair.IsFixed)
                {
                    AllRepairsFixed = false;
                    break;
                }
            }
            if (AllRepairsFixed)
            {
                ChangeMachineReadiness(AllRepairsFixed);
            }
        }

        /// <summary>
        /// Changes the machine readiness status based on all repairs being fixed.
        /// </summary>
        /// <param name="AllRepairsFixed">Indicates whether all repairs are fixed.</param>
        private void ChangeMachineReadiness(bool AllRepairsFixed)
        {
            if (AllRepairsFixed)
            {
                IsReady = AllRepairsFixed;
            }
        }

        /// <summary>
        /// Enumerates the fields available for sorting machines.
        /// </summary>
        public enum FieldsToSort
        {
            MachineId = 1,
            Brand,
            Model,
            Year,
            Price,
            IsReady
        }

        /// <summary>
        /// Enumerates the fields available for changing machine attributes.
        /// </summary>
        public enum FieldsToChange
        {
            MachineId = 1,
            Brand,
            Model,
            Year,
            Price,
            IsReady,
            Repairs
        }

        /// <summary>
        /// Initiates the process of changing a machine attribute by prompting the user for input.
        /// </summary>
        /// <param name="field">The field to change.</param>
        public void ChangeMachine(FieldsToChange field)
        {
            PrintFieldValue(field);
            SetValueField(field);
        }

        /// <summary>
        /// Prints the current value of the specified field and prompts the user for the new value.
        /// </summary>
        /// 
        private void PrintFieldValue(FieldsToChange field)
        {
            string fieldMachine = field.ToString();
            string fieldValue = fieldMachine switch
            {
                "Brand" => Brand.ToString(),
                "Model" => Model.ToString(),
                "Year" => Year.ToString(),
                "Price" => Price.ToString(),
                _ => throw new ArgumentException(),
            };
            Console.WriteLine($"Enter a value for the field to be modified ({fieldMachine}:{fieldValue})");
        }

        /// <summary>
        /// Sets the value of the specified field based on user input.
        /// </summary>
        /// <param name="field">The field to set.</param>
        private void SetValueField(FieldsToChange field)
        {
            // Dictionary to map each field type to its corresponding action.
            var fieldDictionary = new Dictionary<FieldsToChange, Action>
            {
                // Assigning actions to each field type.
                { FieldsToChange.Brand, () => Brand = SetCorrectValue<string>() },
                { FieldsToChange.Model,() => Model = SetCorrectValue<string>() },
                { FieldsToChange.Year, () => Year = SetCorrectValue<int>() },
                { FieldsToChange.Price, () => Price = SetCorrectValue<double>() },
            };

            // Check if the specified field is supported.
            if (!fieldDictionary.ContainsKey(field))
                throw new ArgumentException();

            // Invoke the corresponding action for the specified field.
            fieldDictionary[field].Invoke();
        }

        /// <summary>
        /// Parses and validates user input to ensure it matches the specified type.
        /// </summary>
        /// <typeparam name="T">The type to parse the input into.</typeparam>
        /// <returns>The parsed and validated value.</returns>
        private static T SetCorrectValue<T>()
        {
            T value;
            while (!TryParseValue(Console.ReadLine(), out value) || Comparer<T>.Default.Compare(value, default) < 0 || value == null)
            {
                Console.WriteLine("The entered value is incorrect! Try again: ");
            }
            return value;
        }

        /// <summary>
        /// Attempts to parse the input string into the specified type.
        /// </summary>
        /// <typeparam name="T">The type to parse the input into.</typeparam>
        /// <param name="input">The input string to parse.</param>
        /// <param name="value">The parsed value if parsing was successful.</param>
        /// <returns>True if parsing was successful, otherwise false.</returns>
        private static bool TryParseValue<T>(string input, out T value)
        {
            try
            {
                input = Regex.Unescape(input);

                // Check for special characters.
                if (input.Any(c => char.IsControl(c)))
                {
                    value = default;
                    return false;
                }
                value = (T)Convert.ChangeType(input, typeof(T));
                return true;
            }
            catch (FormatException)
            {
                value = default;
                return false;
            }
        }

        /// <summary>
        /// Creates a formatted table with the specified column names.
        /// </summary>
        /// <param name="columnNames">The names of the columns.</param>
        /// <returns>A string representing the formatted table.</returns>
        public string CreateTable(params string[] columnNames)
        {
            int windowWidth = Console.WindowWidth - 4;

            int numColumns = columnNames.Length;
            int columnWidth = windowWidth / numColumns;

            string? table = null;
            string separator = "┼";

            // Generate the separator line.
            separator = ITableMachineCreator.GetFullSeparator(numColumns, columnWidth, separator);

            // Append header row to the table.
            table += "\n│";
            table = ITableMachineCreator.GetTableValue(columnNames, columnWidth, table);

            return table + "\n" + separator;
        }

        /// <summary>
        /// Adds a randomly generated repair to the list of repairs.
        /// </summary>
        public void CreateRandomRepair()
        {
            Repairs.Add(new Repair());
        }
    }
}
