﻿using DataProcessing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataProcessing
{
    /// <summary>
    /// This abstract class serves as a base for data-related functionality and includes an event for data updates.
    /// </summary>
    public abstract class Data
    {
        /// <summary>
        /// Occurs when the data is updated.
        /// </summary>
        public event EventHandler<DataUpdateEventArgs>? Updated;

        /// <summary>
        /// Updates the data and raises the Updated event.
        /// </summary>
        public void Update()
        {
            // Generate the Updated event with MyTypeUpdatedEventArgs object.
            OnUpdated(new DataUpdateEventArgs(DateTime.Now));
        }

        /// <summary>
        /// Raises the Updated event.
        /// </summary>
        /// <param name="e">The event arguments.</param>
        protected void OnUpdated(DataUpdateEventArgs e)
        {
            Updated?.Invoke(this, e);
        }
    }
}